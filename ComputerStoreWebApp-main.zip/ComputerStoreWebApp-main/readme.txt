# tài khoản admin
wow112
khoivo99122

# fix thanhtoan update cart
- Giỏ hàng sẽ update lại giá và giảm giả + tổng giả sản phẩm
- Sửa lại chức năng thanh toán lâu lâu bị lỗi tổng giá hóa đơn khi thêm vào database
# update 2
- Thêm quản lý hóa đơn + chi tiết hóa Đơn xử lí lại phần thanh toán
- Sau khi thanh toán - số lượng mua của khách vào số lượng tồn kho
# update 3
- Sửa quản lý hóa đơn cho cả người dùng + admin
- Chi tiết hóa đơn phân quyền admin có thể coi tất cả, người dùng chỉ coi được của người dùng đang đăng nhập
và khi đổi đường dẫn sang chi tiết hóa đơn của người khác sẽ bị đưa về trang chính
- Chỉnh giao diện cho chi tiết hóa đơn
- Hoàn trả hóa đơn chỉ hiệu dụng sau khi đặt hàng 1 ngày kể từ ngày hóa Đơn
# update 4
- Phân quyền cho các quyền quản lý user, product
# update 5
- sửa billPage đặt đã thanh toán (set quyền)
- sửa một số giao diện 
# update 6 
- sửa xóa sản phẩm của admin khi ở trang search
- Sửa giao diện HomePage
- loading img = lazy
# update 6.1
- cập nhật lại file ảnh ở backend
# update 7
- cập nhật banner, navigator
- xử lí hover cho các thẻ
- backend sửa lỗi không tạo ngày cho hóa đơn đầu tiên