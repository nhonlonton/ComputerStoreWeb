export const API_URL = "http://localhost:5000";
// export const API_URL = process.env.normal_url;
export const imgAPI_URL = "http://localhost:5000/images/";
// export const imgAPI_URL = process.env.img_url;
