import React, { Component } from "react";

class NotFoundPage extends Component {
  render() {
    return <div>Không tìm thấy trang </div>;
  }
}

export default NotFoundPage;
