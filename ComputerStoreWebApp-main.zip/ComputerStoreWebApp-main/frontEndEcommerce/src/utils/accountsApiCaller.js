// import axios from "axios";
// import * as Config from "./../constants/Config";

// export default function accountsCallApi(endpoint, method, body) {
//   return axios({
//     method: method,
//     url: `${Config.accountsAPI_URL}/${endpoint}`,
//     data: body,
//   }).catch((error) => {
//     // return error;
//     // console.log(error);
//   });
// }
